export type Channel = { id: string; name: string; type: 'text' | 'voice' }
export type Community = {
  id: string
  name: string
  emoji: string
  color: string
  description: string
  channels: Channel[]
  logoDataUrl?: string | null
  bannerDataUrl?: string | null
  requiresApproval?: boolean
}

export const COMMUNITIES: Community[] = [
  {
    id: 'colegio-apoio',
    name: 'Colégio Apoio',
    emoji: '🏫',
    color: '#f0a35e',
    description: 'A comunidade oficial para aprender, conversar e crescer juntos no Colégio Apoio.',
    requiresApproval: true,
    channels: [
      { id: 'geral', name: 'geral', type: 'text' },
      { id: 'avisos', name: 'avisos', type: 'text' },
      { id: 'duvidas', name: 'dúvidas', type: 'text' },
      { id: 'estudos', name: 'estudos', type: 'text' },
      { id: 'sala-voz', name: 'sala de voz', type: 'voice' },
    ],
  },
]
