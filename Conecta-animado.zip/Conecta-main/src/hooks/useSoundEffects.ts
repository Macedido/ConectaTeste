import { useCallback, useEffect, useRef, useState } from 'react'

type SoundName = 'tap' | 'send' | 'success' | 'notice'

const soundMap: Record<SoundName, { frequency: number; duration: number; volume: number; type: OscillatorType }> = {
  tap: { frequency: 440, duration: 0.045, volume: 0.025, type: 'sine' },
  send: { frequency: 620, duration: 0.07, volume: 0.035, type: 'sine' },
  success: { frequency: 660, duration: 0.09, volume: 0.04, type: 'triangle' },
  notice: { frequency: 520, duration: 0.08, volume: 0.028, type: 'sine' },
}

export function useSoundEffects() {
  const [enabled, setEnabled] = useState(() => localStorage.getItem('conecta-sound') !== 'off')
  const contextRef = useRef<AudioContext | null>(null)

  useEffect(() => { localStorage.setItem('conecta-sound', enabled ? 'on' : 'off') }, [enabled])

  const play = useCallback((name: SoundName) => {
    if (!enabled || window.matchMedia('(prefers-reduced-motion: reduce)').matches) return
    try {
      const context = contextRef.current ?? new AudioContext()
      contextRef.current = context
      const config = soundMap[name]
      const oscillator = context.createOscillator()
      const gain = context.createGain()
      oscillator.type = config.type
      oscillator.frequency.setValueAtTime(config.frequency, context.currentTime)
      gain.gain.setValueAtTime(0.0001, context.currentTime)
      gain.gain.exponentialRampToValueAtTime(config.volume, context.currentTime + 0.008)
      gain.gain.exponentialRampToValueAtTime(0.0001, context.currentTime + config.duration)
      oscillator.connect(gain).connect(context.destination)
      oscillator.start()
      oscillator.stop(context.currentTime + config.duration + 0.01)
    } catch {
      // Sound is an enhancement only; unsupported browsers keep the app usable.
    }
  }, [enabled])

  return { enabled, setEnabled, play }
}
