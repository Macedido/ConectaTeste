import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";
const app = new Hono();

type UserRole = "owner" | "admin" | "professor" | "aluno";
type UserProfile = {
  id: string;
  email: string;
  name: string;
  bio: string;
  role: UserRole;
  avatarDataUrl: string | null;
  bannerDataUrl: string | null;
  joinedAt: string;
  courses: string[];
  pendingCourses: string[];
};

const courseIds = new Set(["colegio-apoio"]);
const builtInChannels: Record<string, Set<string>> = {
  "colegio-apoio": new Set(["geral", "avisos", "duvidas", "estudos", "sala-voz"]),
};
const OWNER_EMAIL = "gabrieltmacedo@aluno.colegioapoio.net";
const requestLimits = new Map<string, { count: number; resetAt: number }>();
const adminClient = () => createClient(
  Deno.env.get("SUPABASE_URL")!,
  Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
  { auth: { autoRefreshToken: false, persistSession: false } },
);

async function authenticatedUser(c: any) {
  const token = c.req.header("Authorization")?.replace(/^Bearer\s+/i, "");
  if (!token) return null;
  const { data, error } = await adminClient().auth.getUser(token);
  return error ? null : data.user;
}

async function profileFor(user: any): Promise<UserProfile> {
  const key = `profile:${user.id}`;
  const saved = await kv.get(key) as UserProfile | undefined;
  const ownerEmail = OWNER_EMAIL;
  if (saved) {
    let changed = false;
    if (!Array.isArray(saved.courses)) {
      saved.courses = [];
      changed = true;
    }
    if (!Array.isArray(saved.pendingCourses)) {
      saved.pendingCourses = [];
      changed = true;
    }
    if (ownerEmail && user.email?.toLowerCase() === ownerEmail && saved.role !== "owner") {
      saved.role = "owner";
      changed = true;
    }
    if (changed) await kv.set(key, saved);
    return saved;
  }

  const profile: UserProfile = {
    id: user.id,
    email: user.email ?? "",
    name: user.user_metadata?.full_name ?? user.email?.split("@")[0] ?? "Aluno",
    bio: "",
    role: ownerEmail && user.email?.toLowerCase() === ownerEmail ? "owner" : "aluno",
    avatarDataUrl: null,
    bannerDataUrl: null,
    joinedAt: user.created_at ?? new Date().toISOString(),
    courses: [],
    pendingCourses: [],
  };
  await kv.set(key, profile);
  return profile;
}

function requestedCourses(value: unknown): string[] {
  if (!Array.isArray(value)) return [];
  return [...new Set(value.filter((course): course is string => typeof course === "string" && validCommunityId(course)))];
}

async function knownCourse(courseId: string): Promise<boolean> {
  return courseIds.has(courseId) || !!await kv.get(`community:${courseId}`);
}

function validCommunityId(value: unknown): value is string {
  return typeof value === "string" && /^[a-z0-9]+(?:-[a-z0-9]+)*$/.test(value) && value.length <= 48;
}

function validImageDataUrl(value: unknown): value is string | null {
  return value === null || (typeof value === "string" && value.length <= 2_100_000 &&
    /^data:image\/(png|jpe?g|webp|gif);base64,[a-z0-9+/]+=*$/i.test(value));
}

function withinRateLimit(key: string, maxRequests: number, windowMs: number): boolean {
  const now = Date.now();
  if (requestLimits.size > 10_000) {
    for (const [storedKey, value] of requestLimits) {
      if (value.resetAt <= now) requestLimits.delete(storedKey);
    }
  }
  const current = requestLimits.get(key);
  if (!current || current.resetAt <= now) {
    requestLimits.set(key, { count: 1, resetAt: now + windowMs });
    return true;
  }
  if (current.count >= maxRequests) return false;
  current.count += 1;
  return true;
}

async function validMessageChannel(channel: string): Promise<boolean> {
  const [communityId, channelId, ...extra] = channel.split("::");
  if (extra.length || !communityId || !channelId || !/^[a-z0-9-]{1,48}$/.test(communityId) || !/^[a-z0-9-]{1,48}$/.test(channelId)) return false;
  const community = await kv.get(`community:${communityId}`) as { channels?: Array<{ id?: string }> } | undefined;
  if (community) return !!community.channels?.some((item) => item.id === channelId);
  return !!builtInChannels[communityId]?.has(channelId);
}

async function communityFor(id: string): Promise<{ id: string; requiresApproval?: boolean } | null> {
  const stored = await kv.get(`community:${id}`) as { id: string; requiresApproval?: boolean } | null;
  if (stored) return stored;
  return id === "colegio-apoio" ? { id, requiresApproval: true } : null;
}

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

app.get("/make-server-b92ddf44/communities", async (c) => {
  return c.json(await kv.getByPrefix("community:") as unknown[]);
});

app.post("/make-server-b92ddf44/communities", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Entre para criar uma comunidade." }, 401);
  if ((await profileFor(user)).role !== "owner") return c.json({ error: "Apenas o proprietário pode criar comunidades." }, 403);
  const body = await c.req.json().catch(() => ({}));
  const id = validCommunityId(body.id) ? body.id : "";
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 60) : "";
  const description = typeof body.description === "string" ? body.description.trim().slice(0, 240) : "";
  const emoji = typeof body.emoji === "string" ? body.emoji.slice(0, 8) : "📚";
  const color = typeof body.color === "string" && /^#[0-9a-f]{6}$/i.test(body.color) ? body.color : "#a9e58b";
  const channels = Array.isArray(body.channels) ? body.channels.slice(0, 12).filter((channel: any) =>
    channel && typeof channel.id === "string" && /^[a-z0-9-]{1,48}$/.test(channel.id) &&
    typeof channel.name === "string" && ["text", "voice"].includes(channel.type),
  ).map((channel: any) => ({ id: channel.id, name: channel.name.slice(0, 40), type: channel.type })) : [];
  const logoDataUrl = validImageDataUrl(body.logoDataUrl) ? body.logoDataUrl : null;
  const bannerDataUrl = validImageDataUrl(body.bannerDataUrl) ? body.bannerDataUrl : null;
  if (!id || !name || channels.length === 0 || courseIds.has(id)) return c.json({ error: "Nome, identificador e ao menos um canal válido são obrigatórios." }, 400);
  if (await kv.get(`community:${id}`)) return c.json({ error: "Já existe uma comunidade com esse nome." }, 409);
  const requiresApproval = body.requiresApproval === true;
  const community = { id, name, emoji, color, description, channels, logoDataUrl, bannerDataUrl, requiresApproval };
  await kv.set(`community:${id}`, community);
  return c.json(community, 201);
});

app.put("/make-server-b92ddf44/communities/:id", async (c) => {
  const user = await authenticatedUser(c);
  if (!user || (await profileFor(user)).role !== "owner") return c.json({ error: "Apenas o proprietário pode editar comunidades." }, 403);
  const id = c.req.param("id");
  if (!validCommunityId(id)) return c.json({ error: "Comunidade inválida." }, 400);
  const body = await c.req.json().catch(() => ({}));
  const current = await communityFor(id);
  if (!current) return c.json({ error: "Comunidade não encontrada." }, 404);
  const name = typeof body.name === "string" ? body.name.trim().slice(0, 60) : "";
  const description = typeof body.description === "string" ? body.description.trim().slice(0, 240) : "";
  const emoji = typeof body.emoji === "string" ? body.emoji.slice(0, 8) : "📚";
  const color = typeof body.color === "string" && /^#[0-9a-f]{6}$/i.test(body.color) ? body.color : "#a9e58b";
  const channels = Array.isArray(body.channels) ? body.channels.slice(0, 20).filter((channel: any) =>
    channel && typeof channel.id === "string" && /^[a-z0-9-]{1,48}$/.test(channel.id) &&
    typeof channel.name === "string" && channel.name.trim() && ["text", "voice"].includes(channel.type),
  ).map((channel: any) => ({ id: channel.id, name: channel.name.trim().slice(0, 40), type: channel.type })) : [];
  if (!name || channels.length === 0) return c.json({ error: "Nome e ao menos um canal são obrigatórios." }, 400);
  const community = { id, name, description, emoji, color, channels,
    logoDataUrl: validImageDataUrl(body.logoDataUrl) ? body.logoDataUrl : null,
    bannerDataUrl: validImageDataUrl(body.bannerDataUrl) ? body.bannerDataUrl : null,
    requiresApproval: body.requiresApproval === true };
  if (id === "colegio-apoio") {
    // Built-in data is not stored in KV until an owner customizes it.
    await kv.set(`community:${id}`, community);
  } else {
    await kv.set(`community:${id}`, community);
  }
  return c.json(community);
});

// Health check endpoint
app.get("/make-server-b92ddf44/health", (c) => {
  return c.json({ status: "ok" });
});

app.post("/make-server-b92ddf44/signup", async (c) => {
  const origin = c.req.header("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  if (!withinRateLimit(`signup:${origin}`, 5, 60 * 60 * 1000)) {
    return c.json({ error: "Muitas tentativas de cadastro. Tente novamente mais tarde." }, 429);
  }
  const body = await c.req.json().catch(() => ({}));
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const name = typeof body.name === "string" ? body.name.trim() : "";
  const password = typeof body.password === "string" ? body.password : "";
  const courses = requestedCourses(body.courses);
  const communities = await Promise.all(courses.map(communityFor));
  if (!email || !name || password.length < 6 || courses.length === 0 || communities.some((community) => !community)) {
    return c.json({ error: "Informe nome, e-mail, senha com ao menos 6 caracteres e escolha um curso." }, 400);
  }

  const { data, error } = await adminClient().auth.admin.createUser({
    email,
    password,
    email_confirm: true,
    user_metadata: { full_name: name },
  });
  if (error || !data.user) return c.json({ error: error?.message ?? "Não foi possível criar a conta." }, 400);

  const profile = await profileFor(data.user);
  profile.courses = courses.filter((_, index) => !communities[index]?.requiresApproval);
  profile.pendingCourses = courses.filter((_, index) => communities[index]?.requiresApproval);
  await kv.set(`profile:${profile.id}`, profile);
  return c.json({ id: profile.id });
});

app.get("/make-server-b92ddf44/profile", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Sessão inválida." }, 401);
  return c.json(await profileFor(user));
});

app.put("/make-server-b92ddf44/profile", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Sessão inválida." }, 401);
  const profile = await profileFor(user);
  const body = await c.req.json().catch(() => ({}));
  if (typeof body.name === "string" && body.name.trim()) profile.name = body.name.trim().slice(0, 60);
  if (typeof body.bio === "string") profile.bio = body.bio.slice(0, 300);
  if (validImageDataUrl(body.avatarDataUrl)) profile.avatarDataUrl = body.avatarDataUrl;
  if (validImageDataUrl(body.bannerDataUrl)) profile.bannerDataUrl = body.bannerDataUrl;
  await kv.set(`profile:${user.id}`, profile);
  return c.json(profile);
});

app.post("/make-server-b92ddf44/courses", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Entre para participar de um curso." }, 401);
  const body = await c.req.json().catch(() => ({}));
  if (typeof body.courseId !== "string" || !await knownCourse(body.courseId)) {
    return c.json({ error: "Curso inválido." }, 400);
  }
  const profile = await profileFor(user);
  const community = await communityFor(body.courseId);
  if (community?.requiresApproval) {
    profile.pendingCourses = [...new Set([...profile.pendingCourses, body.courseId])];
    await kv.set(`profile:${user.id}`, profile);
    return c.json(profile, 202);
  }
  profile.courses = [...new Set([...profile.courses, body.courseId])];
  await kv.set(`profile:${user.id}`, profile);
  return c.json(profile);
});

app.get("/make-server-b92ddf44/users", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Sessão inválida." }, 401);
  const requester = await profileFor(user);
  const profiles = await kv.getByPrefix("profile:") as UserProfile[];
  return c.json(profiles.map(({ id, email, name, role, joinedAt }) => ({
    id,
    ...(requester.role === "owner" ? { email } : {}),
    name,
    role,
    joinedAt,
  })));
});

app.put("/make-server-b92ddf44/users/role", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Sessão inválida." }, 401);
  if ((await profileFor(user)).role !== "owner") return c.json({ error: "Apenas o proprietário pode alterar papéis." }, 403);
  const body = await c.req.json().catch(() => ({}));
  const email = typeof body.email === "string" ? body.email.trim().toLowerCase() : "";
  const role = body.role as UserRole;
  if (!email || !["admin", "professor", "aluno"].includes(role)) return c.json({ error: "E-mail ou papel inválido." }, 400);

  const client = adminClient();
  let target: any = null;
  for (let page = 1; !target; page++) {
    const { data, error } = await client.auth.admin.listUsers({ page, perPage: 1000 });
    if (error) return c.json({ error: error.message }, 400);
    target = data.users.find((candidate) => candidate.email?.toLowerCase() === email) ?? null;
    if (target || data.users.length < 1000) break;
  }
  if (!target) return c.json({ error: "Essa conta ainda não existe. Peça à pessoa para criar uma conta primeiro." }, 404);
  const targetProfile = await profileFor(target);
  targetProfile.role = role;
  await kv.set(`profile:${target.id}`, targetProfile);
  return c.json({ id: target.id, email: target.email, role });
});

app.get("/make-server-b92ddf44/access-requests", async (c) => {
  const user = await authenticatedUser(c);
  if (!user || (await profileFor(user)).role !== "owner") return c.json({ error: "Apenas o proprietário pode ver solicitações." }, 403);
  const profiles = await kv.getByPrefix("profile:") as UserProfile[];
  return c.json(profiles.flatMap(({ id, name, email, pendingCourses }) => (pendingCourses ?? []).map((communityId) => ({ id, name, email, communityId }))));
});

app.put("/make-server-b92ddf44/access-requests/:userId", async (c) => {
  const user = await authenticatedUser(c);
  if (!user || (await profileFor(user)).role !== "owner") return c.json({ error: "Apenas o proprietário pode aprovar solicitações." }, 403);
  const userId = c.req.param("userId");
  const body = await c.req.json().catch(() => ({}));
  const communityId = typeof body.communityId === "string" ? body.communityId : "";
  const approved = body.approved === true;
  const profile = await kv.get(`profile:${userId}`) as UserProfile | undefined;
  if (!profile || !profile.pendingCourses?.includes(communityId)) return c.json({ error: "Solicitação não encontrada." }, 404);
  profile.pendingCourses = profile.pendingCourses.filter((id) => id !== communityId);
  if (approved) profile.courses = [...new Set([...profile.courses, communityId])];
  await kv.set(`profile:${userId}`, profile);
  return c.json({ ok: true });
});

app.get("/make-server-b92ddf44/messages", async (c) => {
  const channel = c.req.query("channel") ?? "";
  if (!await validMessageChannel(channel)) return c.json({ error: "Canal inválido." }, 400);
  const items = await kv.getByPrefix(`message:${channel}:`);
  return c.json(items.sort((a: any, b: any) => a.createdAt.localeCompare(b.createdAt)));
});

app.post("/make-server-b92ddf44/messages", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Entre para enviar mensagens." }, 401);
  const body = await c.req.json().catch(() => ({}));
  const channel = typeof body.channel === "string" ? body.channel : "";
  const text = typeof body.text === "string" ? body.text.trim().slice(0, 2000) : "";
  const courseId = channel.split("::")[0];
  if (!await validMessageChannel(channel) || !await knownCourse(courseId) || !text) {
    return c.json({ error: "Canal ou mensagem inválidos." }, 400);
  }
  const profile = await profileFor(user);
  if (!profile.courses.includes(courseId) && !["owner", "admin", "professor"].includes(profile.role)) {
    return c.json({ error: "Entre neste curso antes de enviar mensagens." }, 403);
  }
  const createdAt = new Date().toISOString();
  const message = {
    id: crypto.randomUUID(),
    channel,
    author: profile.name,
    avatar: profile.avatarDataUrl ?? "",
    text,
    time: new Date(createdAt).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
    userId: profile.id,
    createdAt,
  };
  await kv.set(`message:${channel}:${message.id}`, message);
  return c.json(message);
});

app.delete("/make-server-b92ddf44/messages/:id", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Sessão inválida." }, 401);
  const channel = c.req.query("channel") ?? "";
  const id = c.req.param("id");
  if (!await validMessageChannel(channel) || !/^[0-9a-f-]{36}$/i.test(id)) return c.json({ error: "Canal ou mensagem inválidos." }, 400);
  const key = `message:${channel}:${id}`;
  const message = await kv.get(key);
  if (!message) return c.json({ error: "Mensagem não encontrada." }, 404);
  const profile = await profileFor(user);
  if (message.userId !== user.id && !["owner", "admin", "professor"].includes(profile.role)) {
    return c.json({ error: "Você não pode apagar esta mensagem." }, 403);
  }
  await kv.del(key);
  return c.json({ ok: true });
});

app.post("/make-server-b92ddf44/ai", async (c) => {
  const user = await authenticatedUser(c);
  if (!user) return c.json({ error: "Entre para conversar com a Conecta IA." }, 401);
  if (!withinRateLimit(`ai:${user.id}`, 12, 60 * 1000)) {
    return c.json({ error: "Muitas perguntas em pouco tempo. Aguarde um minuto para continuar." }, 429);
  }
  const body = await c.req.json().catch(() => ({}));
  const messages = Array.isArray(body.messages)
    ? body.messages.filter((message: any) =>
        message && ["user", "assistant"].includes(message.role) && typeof message.content === "string",
      ).slice(-16).map((message: any) => ({ role: message.role, content: message.content.slice(0, 2500) }))
    : [];
  if (messages.length === 0 || messages[messages.length - 1].role !== "user") {
    return c.json({ error: "Envie uma pergunta para a Conecta IA." }, 400);
  }

  try {
    const response = await fetch("https://text.pollinations.ai/openai", {
      method: "POST",
      headers: { "content-type": "application/json" },
      signal: AbortSignal.timeout(20_000),
      body: JSON.stringify({
        model: "openai",
        temperature: 0.4,
        max_tokens: 1200,
        messages: [
          {
            role: "system",
            content: "Você é a Conecta IA, uma tutora educacional paciente. Explique com clareza, incentive o raciocínio e responda em português quando a pergunta estiver em português.",
          },
          ...messages,
        ],
      }),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) return c.json({ error: "A IA pública está indisponível no momento. Tente novamente." }, 502);
    const text = result.choices?.[0]?.message?.content;
    if (typeof text !== "string" || !text.trim()) return c.json({ error: "A IA não retornou uma resposta válida." }, 502);
    return c.json({ text: text.trim() });
  } catch {
    return c.json({ error: "Não foi possível conectar à IA pública. Tente novamente." }, 502);
  }
});

Deno.serve(app.fetch);
